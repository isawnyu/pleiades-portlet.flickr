Introduction
============

The Flickr Portlet synposizes Flickr content related to places via Pleiades
machine tags.

