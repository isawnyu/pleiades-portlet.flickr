from zope.i18nmessageid import MessageFactory
FlickrPortletMessageFactory = MessageFactory('pleiades.portlet.flickr')


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
